<!-- HORIZONZ_README_PRESERVE -->
<div align="center">

<img src="packaging/android/res/drawable-nodpi/mc_wall_01.jpg" alt="HorizonZ Launcher Banner" width="100%" style="border-radius: 16px; max-height: 280px; object-fit: cover;" />

# 🌅 HorizonZ — Launcher (`Minecraft RUST 26.3` for Android)

**A Modern Jetpack Compose Material 3 Android Launcher & Runtime for [horizon-rust/horizon](https://github.com/horizon-rust/horizon) (Minecraft: Java Edition 26.3 rewritten in 100% Rust)**

<!-- VERSION_BADGE_START -->
[![Release Version](https://img.shields.io/badge/HorizonZ_Launcher-v1.20.0-8BE0FF?style=for-the-badge&logo=android&logoColor=0E2430)](https://github.com/Fadiba21/Horizonz-Launcher/releases)
<!-- VERSION_BADGE_END -->
[![Minecraft Target](https://img.shields.io/badge/Minecraft_Java-26.3_(Rust_Edition)-66BB6A?style=for-the-badge&logo=rust&logoColor=white)](https://github.com/horizon-rust/horizon)
[![Android Port](https://img.shields.io/badge/Engine-Horizon_Android_0.7.5-FF7043?style=for-the-badge&logo=vulkan&logoColor=white)](https://github.com/Vasysik/horizon-android)
[![Mod Registry](https://img.shields.io/badge/Store-playhorizon.dev%2Fmods-D0C6F2?style=for-the-badge&logo=github&logoColor=231D38)](https://playhorizon.dev/mods)
[![Build Status](https://img.shields.io/github/actions/workflow/status/Fadiba21/Horizonz-Launcher/build-apk.yml?branch=main&style=for-the-badge&logo=githubactions&label=APK%20Build)](https://github.com/Fadiba21/Horizonz-Launcher/actions)

<p align="center">
  <a href="#-overview">Overview</a> •
  <a href="#-visual-preview--interface">Visual Preview</a> •
  <a href="#%EF%B8%8F-how-it-works-system-architecture">How It Works</a> •
  <a href="#-key-features">Key Features</a> •
  <a href="#-store--mods-manager-synchronization">Store & Mods</a> •
  <a href="#-building--auto-update-pipeline">Build & CI/CD</a>
</p>

</div>

---

## 🎮 Overview

**HorizonZ Launcher** ([`Fadiba21/Horizonz-Launcher`](https://github.com/Fadiba21/Horizonz-Launcher)) is an official fork of **[horizon-rust/horizon](https://github.com/horizon-rust/horizon)** that brings the **100% Rust rewrite of Minecraft: Java Edition 26.3** to Android devices with a custom, smooth **Material 3 Jetpack Compose** interface inspired by [ZalithLauncher2Plus](https://github.com/Star1xr/ZalithLauncher2Plus).

Unlike traditional Java Edition Android launchers that run a heavy JVM translation layer, **HorizonZ** compiles the entire Minecraft 26.3 client and renderer natively to **ARM64 (`arm64-v8a`)** and **ARMv7 (`armeabi-v7a`)** machine code (`libhorizon_android.so`) powered by **Vulkan (`wgpu`)** and **OpenGL ES 3.0**.

<!-- LATEST_VERSION_START -->
> 📌 **Current Launcher Release:** `HorizonZ v1.20.0` • **Engine Base:** `horizon-rust/horizon (26.3)` + `Vasysik/horizon-android v0.7.5`
<!-- LATEST_VERSION_END -->

---

## 🖼️ Visual Preview & Interface

<table align="center">
  <tr>
    <td align="center" width="50%">
      <img src="packaging/android/res/drawable-nodpi/mc_wall_02.jpg" alt="Dashboard Wallpaper 1" width="100%" style="border-radius: 12px;" />
      <br />
      <sub><b>Main Dashboard & Pixel-Art <code>Minecraft [RUST] 26.3</code> Card</b></sub>
    </td>
    <td align="center" width="50%">
      <img src="packaging/android/res/drawable-nodpi/mc_wall_05.jpg" alt="Dashboard Wallpaper 2" width="100%" style="border-radius: 12px;" />
      <br />
      <sub><b>100% <code>playhorizon.dev/mods</code> Store & Synchronized Manager</b></sub>
    </td>
  </tr>
  <tr>
    <td align="center" width="50%">
      <img src="packaging/android/res/drawable-nodpi/mc_wall_08.jpg" alt="Dashboard Wallpaper 3" width="100%" style="border-radius: 12px;" />
      <br />
      <sub><b>2D/3D Skin Studio with Auto Slim (3px) / Wide (4px) Detection</b></sub>
    </td>
    <td align="center" width="50%">
      <img src="packaging/android/res/drawable-nodpi/mc_wall_11.jpg" alt="Dashboard Wallpaper 4" width="100%" style="border-radius: 12px;" />
      <br />
      <sub><b>Creeper-Face <code>HORIZONZ</code> Native Splash & 0%-Overhead Sleep Mode</b></sub>
    </td>
  </tr>
</table>

---

## ⚙️ How It Works (System Architecture)

HorizonZ is engineered around a **Dual-Process Android Architecture** so the launcher UI consumes **0% CPU and 0% GPU** while you are inside Minecraft 26.3:

```text
┌───────────────────────────────────────────────────────────────────────────────────┐
│                        PROCESS 1: dev.horizon.android (UI)                        │
│  ┌─────────────────────┐   ┌────────────────────────┐   ┌──────────────────────┐  │
│  │ ZalithMainActivity  │──▶│  HorizonNativeBridge   │──▶│HorizonDownloadService│  │
│  │ (Jetpack Compose)   │   │ (Config, Store, Skins) │   │ (Foreground Notif)   │  │
│  └─────────┬───────────┘   └───────────┬────────────┘   └──────────────────────┘  │
│            │                           │ Writes synced config & validated .hmod   │
│            │ Enters 0% CPU/GPU         ▼                                          │
│            │ Deep Sleep on ON_STOP  [App Data Storage: $HORIZON_HOME]             │
│            │                        ├─ android-launcher.json (v0.7.5 schema)      │
│            │                        ├─ options.txt / horizon-extras.txt           │
│            │                        ├─ horizon-controller.txt / keypad.json       │
│            │                        ├─ horizon-mods/<id>.hmod & horizon-mods.txt  │
│            │                        └─ .local/horizon-client/26.3/ (Mojang Assets)│
└────────────┼───────────────────────────┼──────────────────────────────────────────┘
             │ Launches Intent           │ Reads directly via Rust std::fs & JNI
             ▼                           ▼
┌───────────────────────────────────────────────────────────────────────────────────┐
│                     PROCESS 2: dev.horizon.android:game (Native)                  │
│  ┌─────────────────────────────────────────────────────────────────────────────┐  │
│  │ HorizonActivity (NativeActivity) + Separate-Window Creeper Splash Dialog    │  │
│  │  • Renders Black 8-bit "HORIZONZ" (with Creeper Face 'O') & Progress Bar    │  │
│  │  • Tracks real-time Rust boot milestones in `zalith-game-boot.txt`          │  │
│  └─────────────────────────────────────┬───────────────────────────────────────┘  │
│                                        ▼                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────┐  │
│  │ libhorizon_android.so (Rust 26.3 Client • Vulkan / WGPU / OpenGL ES 3.0)    │  │
│  │  • Bypasses stock debug pages (`HORIZON_SHOW_INTERNAL_UI` guard)            │  │
│  │  • Injects custom player skin into `player/wide` & `player/slim` atlases    │  │
│  │  • Loads validated `.hmod` packages, `.hshader` WGSL shaders & 26.3 worlds  │  │
│  └─────────────────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────────────────────────────┘
```

### 🔄 Step-by-Step Runtime Workflow

1. **Startup & Auto-Update Detection (`checkGithubLatestReleaseUpdate`)**
   - Once per session on startup, HorizonZ queries the GitHub Releases API of [`Fadiba21/Horizonz-Launcher`](https://github.com/Fadiba21/Horizonz-Launcher/releases).
   - It compares the installed version against all published HorizonZ releases, automatically picking the **highest semantic version** (e.g., if `v1.9` is installed and `v1.10` and `v1.20` exist, it selects `v1.20`) and slides down an in-app notification banner (`New Version!!`) with **Update** and **Later** actions.
2. **Official On-Device Minecraft 26.3 Asset Installer (`official_install.rs` + `HorizonDownloadService`)**
   - Downloads official Minecraft 26.3 client assets from Mojang CDN, extracts 32 worldgen registries, and verifies 60 Bedrock touch control icons.
   - Supports real-time **Pause**, **Resume**, **Cancel** (with confirmation dialog and immediate `.part` file deletion), **Smart Repair** (verifies SHA-256/size of existing files and only repairs missing or corrupted assets), and a live **Android Foreground Service Notification** displaying progress percentage, download speed (`MB/s`), and source URL.
3. **Splash Screen Handshake & 0%-Overhead Launcher Sleep**
   - Pressing **PLAY** opens `HorizonActivity` (`:game` process) with a dedicated full-screen **HORIZONZ** splash dialog (featuring a custom 8x8 blocky Minecraft font where the letter `O` is a Creeper face).
   - The splash screen tracks real-time engine milestones (`25%` Catalog → `45%` Vulkan Surface → `70%` Resources & Skin → `100%` Main Menu Ready) and only fades out after the 3D panorama swapchain frame is presented.
   - As soon as the game window takes focus, `ZalithMainActivity` enters **Deep Sleep (`isGameProcessSleeping = true`)**, halting all Compose animations, background coroutines, and clearing bitmap caches (`trimMemoryCaches()`), then seamlessly restores the launcher UI when you exit the game.

---

## ✨ Key Features

| Category | Feature Highlights |
| :--- | :--- |
| **🎨 UI & Dynamic Themes** | • **Zalith-Inspired Material 3 Layout**: Clean top bar, morphing navigation indicator, 16:9 HD Minecraft wallpaper carousel, and custom pixel-art **`Minecraft [RUST] 26.3`** badge.<br>• **Real-Time Reactive Themes**: Switch instantly between `Material You (Dynamic)`, `Embermire Dark`, `Horizon Rust`, and `Emerald AMOLED` (plus Android 12+ wallpaper color extraction). |
| **🛒 Official `playhorizon.dev/mods` Store** | • **100% Native Horizon Registry**: Browse, search, filter, and download **Mods (`.hmod`)**, **Native Mods (`.hnmod`)**, **Modpacks (`.hpack`)**, **Resource Packs (`.zip`)**, and **Shader Packs (`.hshader`)** directly from [`playhorizon.dev/mods`](https://playhorizon.dev/mods) (`https://horizon-rust.github.io/horizon-mods/index.json`).<br>• **Smart Status & Version Guard**: Tracks `✓ Installed`, `↑ Update (vOld → vNew)`, `Cancel` (with `.part` cleanup), and checks Minecraft `26.3` compatibility before downloading. |
| **📂 Synchronized Files & Mods Manager** | • **Two-Way Sync with Store**: Deleting, importing, or toggling any item in **Files & Mods** immediately updates `zalith-store-installed.json`, `horizon-mods.txt`, `hmod_list.json`, and `options.txt`.<br>• **Self-Healing `.hmod` Validator**: Automatically deduplicates `<id>-<version>.hmod` into canonical `horizon-mods/<id>.hmod` and repairs any archive missing `EOCD` or `horizon-mod.toml`.<br>• **Delete Confirmation Pop-Up & Smooth Animations**: Animated confirmation dialog before deleting any file, plus expandable manifest drawers and smooth tab transitions. |
| **👕 3D/2D Skin Studio & Accounts** | • **Automatic Skin Geometry Detector**: Imports 64x64 or 64x32 PNG skins from Android Photo Picker, inspects arm transparency zones `(54, 20)` to auto-detect **Slim (3px Alex)** vs **Wide (4px Steve)** models, and renders an interactive Front/Back full-body preview.<br>• **Built-In Presets & Engine Sync**: Includes Classic Steve, Alex, Gothic Girl, Cyber Knight, and Emerald Ranger presets synced directly into the 26.3 engine. |
| **🎮 Horizon Android v0.7.5 Settings** | • **Display & Renderer**: Choose `Vulkan Compatibility`, `Vulkan High Performance`, or `OpenGL ES`, adjust `Resolution Scale (25%–100%)`, `Screen Aspect Ratio (Native / 16:9 / 4:3 / 1:1)`, `Refresh Rate (60–144 Hz)`, `Avoid Camera Cutout`, and `ADPF Performance Hints`.<br>• **Touch, Gyro & Controller**: Configure `Sprint Toggle`, `Inventory Touch Action Buttons`, `Gyroscope Aiming`, `Gamepad Vibration`, and `Controller Menu Navigation (Focus vs Virtual Pointer)`.<br>• **Horizon 26.3 Extras (`horizon-extras.txt`)**: Built-in toggles for `Fullbright`, `Dynamic Handheld Lights`, `Auto-Reconnect`, and `Mouse Tweaks & Inventory Sort`. |

---

## 🔗 Store & Mods Manager Synchronization

HorizonZ ensures that **Store** and **Files & Mods Manager** never go out of sync or create duplicate mods:

* **Canonical Single-File Storage (`horizon-mods/<id>.hmod`)**: Every mod is stored under its sanitized canonical ID (e.g., `fps_overlay.hmod`, `minimap.hmod`, `keystrokes.hmod`, `mod_menu.hmod`).
* **Clean Overwrite on Update**: Clicking **`↑ Update`** removes any older versioned file first and overwrites `horizon-mods/<id>.hmod` in place—preventing duplicate entries in both the Manager and Minecraft's in-game `Options > Mods` screen.
* **No Redundant Re-Install**: Items already at the latest version display a locked **`✓ Installed`** badge so tapping them never re-triggers a redundant download.

---

## 🛠️ Building & Auto-Update Pipeline

### 1. Automated GitHub Actions Build (`.github/workflows/build-apk.yml`)
Every push to `main` (or manual `workflow_dispatch` trigger) compiles both **ARM64 (`arm64-v8a`)** and **ARMv7 (`armeabi-v7a`)** release APKs using Android SDK 35, Android NDK `28.2.13676358`, Rust Stable, and Gradle `8.10.2`, then publishes them to [GitHub Releases](https://github.com/Fadiba21/Horizonz-Launcher/releases).

### 2. Drop-In `Update/` ZIP Auto-Extractor (`scripts/apply_update_zip.py`)
To apply a new HorizonZ source update package (e.g., `HorizonZ1.20.zip`):
1. Upload the `.zip` file into the [`Update/`](Update/) directory on the `main` branch.
2. GitHub Actions automatically extracts the update into the repository root, **preserves this `README.md` (updating only the version badges)**, removes the processed `.zip` from `Update/`, commits the updated source tree, and builds the new APKs.

### 3. Local CLI Build (`tools/android_build.py`)
```bash
# Build ARM64 Release APK locally (requires Android SDK 35 + NDK 28 + Rust)
python3 tools/android_build.py --abi arm64-v8a --profile release --public
```

---

## 📜 Credits & Upstream Projects

* **[horizon-rust/horizon](https://github.com/horizon-rust/horizon)** — Upstream Minecraft: Java Edition 26.3 client & server written in Rust.
* **[Vasysik/horizon-android](https://github.com/Vasysik/horizon-android)** — Native Android runtime port, Vulkan/GLES backend, and touch control bridges.
* **[horizon-rust/horizon-mods](https://github.com/horizon-rust/horizon-mods)** ([playhorizon.dev/mods](https://playhorizon.dev/mods)) — Official reviewed Horizon Mods, Native Mods, Shaders, Resource Packs, and Modpacks registry.
* **[Star1xr/ZalithLauncher2Plus](https://github.com/Star1xr/ZalithLauncher2Plus)** — UI/UX layout and workflow inspiration.

> *Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.*
